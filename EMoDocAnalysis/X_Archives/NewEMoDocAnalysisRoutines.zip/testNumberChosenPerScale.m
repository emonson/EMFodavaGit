% clear all;
% baseName = 'X20_042709b';
% 
% cd('/Users/emonson/Programming/Matlab/EMonson/Fodava/DocumentAnalysis/Analysis');
% fprintf(1,'Loading data set\n');
%     load([baseName '.mat']);

% 'difference', 'norm difference', 'filled', 'entropy', 'random',
% 'correlation'
uncertMeasure = 'entropy';
filledThreshold = 0.8;

overlap = true;
numReplicates = 50; % Not used if overlap=false

leaveOutFracOfTotal = false;    
numLeaveOut = 20;   % Not used if leaveOutFracOfTotal = true;
leaveOutFrac = 0.2;

numPts = length(classes(:,1));
scaleIdx = 1;
for scale = 2:5,
    extIdxs = G.Tree{scale,1}.ExtIdxs;
    % Test randomizing extIdxs order
    % extIdxs = extIdxs(randperm(length(extIdxs)));
    numIdx = 1;
    for num = 40:5:775,
        if (num > length(extIdxs)), break; end;
        numLog(numIdx,scaleIdx) = num;

        fprintf(1,'Choosing scale %d points (%d dups) -- ', scale, num);
            [scaleIdxs,scaleCats] = docChooseScalePoints(classes(:,1),extIdxs,'number',num);

        fprintf(1,'Propagating scale labels\n');
            if (leaveOutFracOfTotal), numLeaveOut = floor(num*leaveOutFrac); end;
            [scaleLabelArray, optCorrect] = propagateLabels3(scaleIdxs,scaleCats,G.P,20,overlap,numLeaveOut,numReplicates);
            [junk,scaleCatOut] = max(scaleLabelArray,[],2);

        scaleCorrect = (scaleCatOut == classes(:,1));
        sc(numIdx,scaleIdx) = sum(scaleCorrect);
        
        if strcmpi(uncertMeasure,'norm difference'),
            labelsSorted = sort(scaleLabelArray,2,'descend');
            labelsSorted = labelsSorted./repmat(sum(labelsSorted,2),[1 size(labelsSorted,2)]);
            uncertainty = 1+diff(labelsSorted(:,1:2),1,2);
        elseif strcmpi(uncertMeasure,'difference'),
            labelsSorted = sort(scaleLabelArray,2,'descend');
            uncertainty = 1+diff(labelsSorted(:,1:2),1,2);
        elseif strcmpi(uncertMeasure,'entropy'),
            normLabels = scaleLabelArray./repmat(sum(scaleLabelArray,2),[1 size(scaleLabelArray,2)]); 
            tmpLog = log10(normLabels);
            tmpLog(isinf(tmpLog)) = 0;
            uncertainty = sum( -1.*normLabels.*tmpLog ,2);
        elseif strcmpi(uncertMeasure,'filled'),
            labelsSorted = sort(scaleLabelArray,2,'descend');
            labelsSorted = labelsSorted./repmat(sum(labelsSorted,2),[1 size(labelsSorted,2)]);
            uncertainty = zeros([size(labelsSorted,1) 1]);
            for jj = 1:length(uncertainty),
                % interp1 needs unique values, so adding a little noise before cumsum...
                tmpRow = cumsum( labelsSorted(jj,:) + 0.00001.*rand([1 size(labelsSorted,2)]), 2 );
                uncertainty(jj) = interp1( [0 tmpRow], [0:size(labelsSorted,2)], filledThreshold );
            end;
        elseif strcmpi(uncertMeasure,'correlation'),
            normLabels = scaleLabelArray./repmat(sum(scaleLabelArray,2),[1 size(scaleLabelArray,2)]);
            uncertainty = zeros([size(labelsSorted,1) 1]);
            for jj = 1:length(uncertainty),
                inNeighborCorrs = corr(normLabelArray(jj,:)',normLabelArray(setdiff(find(G.P(:,jj)),jj),:)');
                uncertainty(jj) = 1-mean(inNeighborCorrs);
            end;
        elseif strcmpi(uncertMeasure,'random'),
            uncertainty = rand([size(scaleLabelArray,1) 1]);
        else
            uncertainty = zeros([size(scaleLabelArray,1) 1]);
        end;
        
        un(numIdx,scaleIdx) = mean(uncertainty);
        pc(numIdx,scaleIdx) = optCorrect*numPts;
        fprintf(1,'scale correct: %d / %d (%4.3f)\n', sum(scaleCorrect), length(scaleCorrect), sum(scaleCorrect)/length(scaleCorrect));

        fprintf(1,'Choosing random points (%d dups) -- ', num);
            [randIdxs,randCats] = docChooseRandomPoints(classes(:,1),'number',num);


        fprintf(1,'Propagating random labels\n');
            randLabelArray = propagateLabels3(randIdxs,randCats,G.P,20,overlap,numLeaveOut,numReplicates);
            [junk,randCatOut] = max(randLabelArray,[],2);
        fprintf(1,'Number all zero propagated results: %d\n', length(find(junk==0.0)) );

        randCorrect = (randCatOut == classes(:,1));
        rc(numIdx,scaleIdx) = sum(randCorrect);
        fprintf(1,'random correct: %d / %d (%4.3f)\n\n', sum(randCorrect), length(randCorrect), sum(randCorrect)/length(randCorrect));
        
        numIdx = numIdx + 1;
    end;
    scaleIdx = scaleIdx + 1;
end;

figure; 
subplot(2,2,1);
plot(numLog,sc,'.-');
title('scale');
subplot(2,2,2);
plot(numLog,rc,'.-');
title('random');
subplot(2,2,3);
plot(numLog,pc,'.-');
if (overlap),
    overlapString = sprintf('Overlapping leaveOuts, numReps=%d',numReplicates);
else
    overlapString = 'Not overlapping leaveOuts';
end;
if (leaveOutFracOfTotal),
    pertotalString = sprintf('Leave out frac=%3.2f',leaveOutFrac);
else
    pertotalString = sprintf('Num left out=%d',numLeaveOut);
end;
titleString = sprintf('%s\n%s\n%s','Propagation cross-valid correct (mean)', overlapString, pertotalString);
title(titleString);
subplot(2,2,4);
plot(numLog,un,'.-');
title([uncertMeasure ' uncertainty measure (mean)']);